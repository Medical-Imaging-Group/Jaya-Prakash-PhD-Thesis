X=linspace(1,length(indxi),length(indxi))*dx*1000; Y=linspace(1,length(indyi),length(indyi))*dy*1000;
value=[1:-1/63:0]'; gray2=[value value value];

figure,
subplot(2,3,1), imagesc(X,Y,BV2);colormap(gray2); colorbar; axis image;ahan=gca;set(ahan,'FontSize',[16],'FontWeight','normal','LineWidth',[1.5]);title('Target');
subplot(2,3,2),imagesc(X,Y,IM2_k_interp(indxi,indyi));colormap(gray2); colorbar;axis image;ahan=gca;set(ahan,'FontSize',[16],'FontWeight','normal','LineWidth',[1.5]);title('Target');
subplot(2,3,3),imagesc(X,Y,IM1_LSQR);colormap(gray2);colorbar;axis image;ahan=gca;set(ahan,'FontSize',[16],'FontWeight','normal','LineWidth',[1.5]);title('LSQR (0.01)');
subplot(2,3,4),imagesc(X,Y,IM3_LSQR);colormap(gray2);colorbar;axis image;ahan=gca;set(ahan,'FontSize',[16],'FontWeight','normal','LineWidth',[1.5]);title('LSQR based Optimal Regularization');
subplot(2,3,5),imagesc(X,Y,IM2_LSQR);colormap(gray2);colorbar;axis image;ahan=gca;set(ahan,'FontSize',[16],'FontWeight','normal','LineWidth',[1.5]);title('BPDN based LSQR');
subplot(2,3,6),imagesc(X,Y,IM4_LSQR);colormap(gray2);colorbar;axis image;ahan=gca;set(ahan,'FontSize',[16],'FontWeight','normal','LineWidth',[1.5]);title('LSQR based Optimal Regularization with BPDN');

