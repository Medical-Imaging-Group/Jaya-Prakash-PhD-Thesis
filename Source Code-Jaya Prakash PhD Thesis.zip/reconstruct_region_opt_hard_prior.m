function [fwd_mesh,pj_error] = reconstruct_region_opt_hard_prior(fwd_fn,frequency,data_fn,output_fn,lambda,iteration)

%HAMID reconstruction:
% reconstruct_region('circle2000_86','region[0 1 2]',100,'test.paa',100,10,'test',0)
% For perturbation approach:
% reconstruct_region('circle2000_86','circle2000_86',100,'test.paa',100,10,'test',0)

% Adopted from Hamid - reoncstruct_region.m
% Phaneendra Yalavarthy
% 11/25/2006

tic;
iteration = 200;
% load fine mesh for fwd solve
fwd_mesh = load_mesh(fwd_fn);


% read data
anom = load_data(data_fn);%New Nirfast
%anom = load(data_fn);%Old Nirfast
anom = log(anom.paa(:,1));

% Initiate projection error
pj_error = [];

% Initiate log file
fid_log = fopen([output_fn '.log'],'w');
fprintf(fid_log,'Forward Mesh   = %s\n',fwd_fn);
% if ischar(recon_basis)
%   fprintf(fid_log,'Basis          = %s\n',recon_basis);
% else
%   fprintf(fid_log,'Basis          = %s\n',num2str(recon_basis));
% end
fprintf(fid_log,'Frequency      = %f MHz\n',frequency);
fprintf(fid_log,'Data File      = %s\n',data_fn);
%fprintf(fid_log,'Initial Reg    = %d\n',lambda);
%fprintf(fid_log,'Filter         = %d\n',filter_n);
fprintf(fid_log,'Output Files   = %s_mua.sol\n',output_fn);
fprintf(fid_log,'               = %s_mus.sol\n',output_fn);

%if exist('region','var')==0
disp('Jacob region');
% Intializations
flag_mesh = 0;
regions = unique(fwd_mesh.region);
R = zeros(length(fwd_mesh.mua), length(regions));
KREC = zeros(length(regions),1);
MuaREC = KREC;

% store the region indices
for i = 1:length(regions)
    R1 = find(fwd_mesh.region == regions(i));
    RL(i) = length(R1);
    R(1:length(R1), i) = R1;
    % KREC(i) = mean(fwd_mesh.kappa(R1));
    MuaREC(i) = mean(fwd_mesh.mua(R1));
    clear R1;
end

for it = 1 : iteration
    
    %mu =  [(KREC);(MuaREC)] ;
    
    disp('calculating regions');
    if ~exist('region','var')
        region = unique(fwd_mesh.region);
    end
    K = region_mapper(fwd_mesh,region);
    
    % Calculate jacobian
    [J,data]=jacobian(fwd_mesh,frequency,fwd_mesh);    %New Nirfast
    J = J.complete;
    J = J*K;
    N2 = (fwd_mesh.mua'*K)./sum(K);
    nn = length(N2);
    
    for i = 1 : nn
        J(:,i) = J(:,i).*N2(i);
    end
    % reduce J into regions!
    
    
    %Read reference data
    clear ref;
    ref(:,1) = log(data.amplitude);
    
    if it==1
        pj_error = [pj_error sum((anom-ref).^2)]
    else
        %             pj_error = [pj_error sum((anom-ref).^2)]
        pj_error = [pj_error sum((anom(val,:)-ref(val,:)).^2)]
    end
    
    disp('---------------------------------');
    disp(['Iteration Number          = ' num2str(it)]);
    disp(['Projection error          = ' num2str(pj_error(end))]);
    
    fprintf(fid_log,'---------------------------------\n');
    fprintf(fid_log,'Iteration Number          = %d\n',it);
    fprintf(fid_log,'Projection error          = %f\n',pj_error(end));
    
    if it ~= 1
        p = (pj_error(end-1)-pj_error(end))*100/pj_error(end-1);
        disp(['Projection error change   = ' num2str(p) '%']);
        fprintf(fid_log,'Projection error change   = %f %%\n',p);
        if ((p) <= 2)
            disp('---------------------------------');
            disp('STOPPING CRITERIA REACHED');
            fprintf(fid_log,'---------------------------------\n');
            fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
            break
        end
    end
    if it==1
        N = J*((J'*J+lambda*eye(size(J,2)))\J');
        diag_data = diag(N);
        sorted_diag_data = (sort(diag_data,'descend'));
        i=1;j=1;
        while(i<7)
            ind_i = find(sorted_diag_data(j)==diag_data(:));
            if ~isempty(ind_i)
                ind_indices(i) = ind_i;
                i=i+1;
            end
            j=j+1;
        end
        
        mu = MuaREC;
        if it==1
            val = (ind_indices)
        end
        
    end
    new_anom = anom(val,:);
    
    clear ind_indices sorted_diag_data
    
    J1 = J(val,:);
    
    clear J;
    
    J = J1;
    
    
    % build hessian
    [nrow,ncol]=size(J);
    Hess = zeros(nrow);
    Hess = (J'*J);
    
    %
    %
    % Add regularization
    if it ~= 1
        lambda = lambda./10^0.25;
    end
    
    % Seems that scatter part is always more noisey. So we will make
    % sure that the regularization for phase is some factor (ratio
    % of amplitude vs phase diagonals of the Hessian) higher.
    % This 1st method not as objective as the second and implemented
    % method.
    %
    % reg = lambda*max(diag(Hess));
    % ph_factor = median(diag(Hess(1:2:end,1:2:end)) ./ ...
    %		       diag(Hess(2:2:end,2:2:end)));
    % reg = ones(nrow,1).*reg;
    % reg(1:2:end) =  reg(1:2:end).*ph_factor;
    % reg = diag(reg);
    
    reg_amp = lambda;%*max(diag(Hess));
    %reg_phs = lambda*max(diag(Hess(2:2:end,2:2:end)));
    reg = ones(ncol,1);
    reg(1:end) = reg(1:end).*reg_amp;
    %reg(2:2:end) = reg(2:2:end).*reg_phs;
    reg = diag(reg);
    
    disp(['Regularization        = ' num2str(reg(1,1))]);
    %disp(['Phs Regularization        = ' num2str(reg(2,2))]);
    fprintf(fid_log,'Regularization        = %f\n',reg(1,1));
    %fprintf(fid_log,'Phs Regularization        = %f\n',reg(2,2));
    Hess = Hess+reg;
    
    % Calculate update
    data_diff = anom(val,:) - ref(val,:);
    %             data_diff = anom-ref;
    foo = (Hess\(J'*data_diff));
    % use region mapper to unregionize!
    
    foo = foo.*N2';
    clear nn N
    foo = K*foo;% K*foo(end/2+1:end)];
    
    
    % Update values
    fwd_mesh.mua = fwd_mesh.mua + (foo);
    
    clear foo Hess Hess_norm tmp data_diff G
    
    
    fid = fopen([output_fn '_mua.sol'],'w');
    
    fprintf(fid,'solution %g ',it);
    fprintf(fid,'-size=%g ',length(fwd_mesh.nodes));
    fprintf(fid,'-components=1 ');
    fprintf(fid,'-type=nodal\n');
    fprintf(fid,'%f ',fwd_mesh.mua);
    fprintf(fid,'\n');
    fclose(fid);
    
    %if it == 1
    fid = fopen([output_fn '_mus.sol'],'w');
    %else
    %    fid = fopen([output_fn '_mus.sol'],'a');
    %end
    fprintf(fid,'solution %g ',it);
    fprintf(fid,'-size=%g ',length(fwd_mesh.nodes));
    fprintf(fid,'-components=1 ');
    fprintf(fid,'-type=nodal\n');
    fprintf(fid,'%f ',fwd_mesh.mus);
    fprintf(fid,'\n');
    fclose(fid);
    
end

% close log file!
time = toc;
fprintf(fid_log,'Computation Time = %f\n',time);
fclose(fid_log);





function [val_int,recon_mesh] = interpolatef2r(fwd_mesh,recon_mesh,val)

% This function interpolates fwd_mesh into recon_mesh
% For the Jacobian it is an integration!
NNC = size(recon_mesh.nodes,1);
NNF = size(fwd_mesh.nodes,1);
NROW = size(val,1);
val_int = zeros(NROW,NNC*2);

for i = 1 : NNF
    if recon_mesh.coarse2fine(i,1) ~= 0
        val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)) = ...
            val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)) + ...
            val(:,i)*recon_mesh.coarse2fine(i,2:end);
        val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)+NNC) = ...
            val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)+NNC) + ...
            val(:,i+NNF)*recon_mesh.coarse2fine(i,2:end);
    elseif recon_mesh.coarse2fine(i,1) == 0
        dist = distance(fwd_mesh.nodes,fwd_mesh.bndvtx,recon_mesh.nodes(i,:));
        mindist = find(dist==min(dist));
        mindist = mindist(1);
        val_int(:,i) = val(:,mindist);
        val_int(:,i+NNC) = val(:,mindist+NNF);
    end
end

for i = 1 : NNC
    if fwd_mesh.fine2coarse(i,1) ~= 0
        recon_mesh.mua(i,1) = (fwd_mesh.fine2coarse(i,2:end) * ...
            fwd_mesh.mua(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
        recon_mesh.mus(i,1) = (fwd_mesh.fine2coarse(i,2:end) * ...
            fwd_mesh.mus(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
        recon_mesh.kappa(i,1) = (fwd_mesh.fine2coarse(i,2:end) * ...
            fwd_mesh.kappa(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
        recon_mesh.region(i,1) = ...
            median(fwd_mesh.region(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
    elseif fwd_mesh.fine2coarse(i,1) == 0
        dist = distance(fwd_mesh.nodes,...
            fwd_mesh.bndvtx,...
            [recon_mesh.nodes(i,1:2) 0]);
        mindist = find(dist==min(dist));
        mindist = mindist(1);
        recon_mesh.mua(i,1) = fwd_mesh.mua(mindist);
        recon_mesh.mus(i,1) = fwd_mesh.mus(mindist);
        recon_mesh.kappa(i,1) = fwd_mesh.kappa(mindist);
        recon_mesh.region(i,1) = fwd_mesh.region(mindist);
    end
end

function [fwd_mesh,recon_mesh] = interpolatep2f(fwd_mesh,recon_mesh)


for i = 1 : length(fwd_mesh.nodes)
    fwd_mesh.mua(i,1) = ...
        (recon_mesh.coarse2fine(i,2:end) * ...
        recon_mesh.mua(recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)));
    fwd_mesh.kappa(i,1) = ...
        (recon_mesh.coarse2fine(i,2:end) * ...
        recon_mesh.kappa(recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)));
    fwd_mesh.mus(i,1) = ...
        (recon_mesh.coarse2fine(i,2:end) * ...
        recon_mesh.mus(recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)));
end


function KKK=region_mapper(mesh,region)

% creates a matrix which is in effect a mapper to move
% between nodal basis or region basis.

nregion = length(region);
nnodes = length(mesh.nodes);

% create empty mapping matrix
K = sparse(nnodes,nregion);

% Assign mapping functions, for each node belonging to each region
for j = 1 : nregion
    K(find(mesh.region==region(j)),j) = 1;
end

% find the total number of assigned nodes
N = full(sum(sum(K)));

% Here if some node is not in region, must account for it
if N ~= length(mesh.nodes)
    KK = sparse(nnodes,nnodes-N);
    for k = 1 : length(region)
        if k == 1
            a = find(mesh.region~=region(k));
        else
            a = intersect(find(mesh.region~=region(k)),a);
        end
    end
    for i = 1 : length(a)
        KK(a(i),i) = 1;
    end
    KKK = [K KK];
else
    KKK = K;
end
